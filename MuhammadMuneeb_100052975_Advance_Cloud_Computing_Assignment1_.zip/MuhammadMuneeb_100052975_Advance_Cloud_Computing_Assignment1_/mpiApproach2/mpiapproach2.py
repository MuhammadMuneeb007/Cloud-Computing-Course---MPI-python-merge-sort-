from mpi4py import MPI
from random import seed
from random import randint
from random import randrange
import random
import numpy as np
import math
import timeit
import time
import sys, getopt
def merge_sort(array, left_index, right_index):
    if left_index >= right_index:
        return

    middle = (left_index + right_index)//2
    merge_sort(array, left_index, middle)
    merge_sort(array, middle + 1, right_index)
    merge(array, left_index, right_index, middle)
def merge(array, left_index, right_index, middle):
    # Make copies of both arrays we're trying to merge

    # The second parameter is non-inclusive, so we have to increase by 1
    left_copy = array[left_index:middle + 1]
    right_copy = array[middle+1:right_index+1]

    # Initial values for variables that we use to keep
    # track of where we are in each array
    left_copy_index = 0
    right_copy_index = 0
    sorted_index = left_index

    # Go through both copies until we run out of elements in one
    while left_copy_index < len(left_copy) and right_copy_index < len(right_copy):

        # If our left_copy has the smaller element, put it in the sorted
        # part and then move forward in left_copy (by increasing the pointer)
        if left_copy[left_copy_index] <= right_copy[right_copy_index]:
            array[sorted_index] = left_copy[left_copy_index]
            left_copy_index = left_copy_index + 1
        # Opposite from above
        else:
            array[sorted_index] = right_copy[right_copy_index]
            right_copy_index = right_copy_index + 1

        # Regardless of where we got our element from
        # move forward in the sorted part
        sorted_index = sorted_index + 1

    # We ran out of elements either in left_copy or right_copy
    # so we will go through the remaining elements and add them
    while left_copy_index < len(left_copy):
        array[sorted_index] = left_copy[left_copy_index]
        left_copy_index = left_copy_index + 1
        sorted_index = sorted_index + 1

    while right_copy_index < len(right_copy):
        array[sorted_index] = right_copy[right_copy_index]
        right_copy_index = right_copy_index + 1
        sorted_index = sorted_index + 1    
def mergeSort(arr):
    if len(arr) > 1:
 
         # Finding the mid of the array
        mid = len(arr)//2
 
        # Dividing the array elements
        L = arr[:mid]
 
        # into 2 halves
        R = arr[mid:]
 
        # Sorting the first half
        mergeSort(L)
 
        # Sorting the second half
        mergeSort(R)
 
        i = j = k = 0
 
        # Copy data to temp arrays L[] and R[]
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1
 
        # Checking if any element was left
        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1
 
        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1 
def printList(arr):
    for i in range(len(arr)):
        print(arr[i], end=" ")
    print()
def customMerge(test_list1,test_list2):
    size_1 = len(test_list1) 
    size_2 = len(test_list2) 
  
    res = [] 
    i, j = 0, 0
  
    while i < size_1 and j < size_2: 
        if test_list1[i] < test_list2[j]:   
          res.append(test_list1[i]) 
          i += 1
  
        else: 
          res.append(test_list2[j]) 
          j += 1
  
    res = res + test_list1[i:] + test_list2[j:]
    return res 
def calculateSend(ranks,nprocs):
    return int(ranks + math.ceil(nprocs/2))
def calculateRec(ranks,nprocs):
    return int(ranks - math.ceil(nprocs/2))
seed(1)

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
nprocs = comm.Get_size()
name = MPI.Get_processor_name()

numberOfProcesses = int(sys.argv[1])
arraySize = int(sys.argv[2])
data=np.arange(1,arraySize)
random.shuffle(data)
data = list(data)
division = int(arraySize/numberOfProcesses) 
 

local_a = int(rank*division)
local_b = int(local_a + division)
subdata = data[local_a:local_b] 


start = timeit.default_timer()

while nprocs>1:    
    mergeSort(subdata)
    
    if rank>=math.floor((nprocs)/2):
        comm.send(list(subdata),dest = calculateRec(rank, nprocs))
        exit(0)
    else:
        data2 = []
        data2 = comm.recv(source = calculateSend(rank, nprocs))
        subdata = customMerge(data2,subdata)    
         
    nprocs = math.ceil(nprocs/2)

 
if rank==0:
    #if len(subdata)== len(data):    
    stop = timeit.default_timer()
    print("Process",rank,"has data",subdata)
    print('Time: ', stop - start)
