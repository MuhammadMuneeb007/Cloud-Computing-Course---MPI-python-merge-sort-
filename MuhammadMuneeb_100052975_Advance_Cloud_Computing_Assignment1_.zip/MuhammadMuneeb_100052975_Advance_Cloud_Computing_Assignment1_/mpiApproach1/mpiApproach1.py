import numpy as np
import time
from mpi4py import MPI
from basic import consumer, do_something, nr_dim, nr_instances
from mpi4py import MPI
from random import seed
from random import randint
from random import randrange
import random
import numpy as np
import math
import timeit
import time
READY, START, DONE, EXIT = 0, 1, 2, 3
comm = MPI.COMM_WORLD
size = comm.size
rank = comm.rank
status = MPI.Status()
def merge_sort(array, left_index, right_index):
    if left_index >= right_index:
        return

    middle = (left_index + right_index)//2
    merge_sort(array, left_index, middle)
    merge_sort(array, middle + 1, right_index)
    merge(array, left_index, right_index, middle)
def merge(array, left_index, right_index, middle):
    # Make copies of both arrays we're trying to merge

    # The second parameter is non-inclusive, so we have to increase by 1
    left_copy = array[left_index:middle + 1]
    right_copy = array[middle+1:right_index+1]

    # Initial values for variables that we use to keep
    # track of where we are in each array
    left_copy_index = 0
    right_copy_index = 0
    sorted_index = left_index

    # Go through both copies until we run out of elements in one
    while left_copy_index < len(left_copy) and right_copy_index < len(right_copy):

        # If our left_copy has the smaller element, put it in the sorted
        # part and then move forward in left_copy (by increasing the pointer)
        if left_copy[left_copy_index] <= right_copy[right_copy_index]:
            array[sorted_index] = left_copy[left_copy_index]
            left_copy_index = left_copy_index + 1
        # Opposite from above
        else:
            array[sorted_index] = right_copy[right_copy_index]
            right_copy_index = right_copy_index + 1

        # Regardless of where we got our element from
        # move forward in the sorted part
        sorted_index = sorted_index + 1

    # We ran out of elements either in left_copy or right_copy
    # so we will go through the remaining elements and add them
    while left_copy_index < len(left_copy):
        array[sorted_index] = left_copy[left_copy_index]
        left_copy_index = left_copy_index + 1
        sorted_index = sorted_index + 1

    while right_copy_index < len(right_copy):
        array[sorted_index] = right_copy[right_copy_index]
        right_copy_index = right_copy_index + 1
        sorted_index = sorted_index + 1    
def mergeSort(arr):
    if len(arr) > 1:
 
         # Finding the mid of the array
        mid = len(arr)//2
 
        # Dividing the array elements
        L = arr[:mid]
 
        # into 2 halves
        R = arr[mid:]
 
        # Sorting the first half
        mergeSort(L)
 
        # Sorting the second half
        mergeSort(R)
 
        i = j = k = 0
 
        # Copy data to temp arrays L[] and R[]
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1
 
        # Checking if any element was left
        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1
 
        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1 
def printList(arr):
    for i in range(len(arr)):
        print(arr[i], end=" ")
    print()
def customMerge(test_list1,test_list2):
    size_1 = len(test_list1) 
    size_2 = len(test_list2) 
  
    res = [] 
    i, j = 0, 0
  
    while i < size_1 and j < size_2: 
        if test_list1[i] < test_list2[j]:   
          res.append(test_list1[i]) 
          i += 1
  
        else: 
          res.append(test_list2[j]) 
          j += 1
  
    res = res + test_list1[i:] + test_list2[j:]
    return res 



#This function will divide the array (seq) into chunks (num)
def chunkIt(seq, num):
    avg = len(seq) / float(num)
    out = []
    last = 0.0

    while last < len(seq):
        out.append(seq[int(last):int(last + avg)])
        last += avg

    return out


###This function will receive data from the producer and send it back to producer for merge.
### It there is no further data to process it will exit.
def consumer_daemon():
    name = MPI.Get_processor_name()
    while True:    
        comm.send(None, dest=0, tag=READY)
        task = []
        
        task = comm.recv(source=0, tag=MPI.ANY_TAG, status=status)
        tag = status.Get_tag()
        if tag == START:
            mergeSort(task)
            comm.send(list(task), dest=0, tag=DONE)
        elif tag == EXIT:
            break
    
    comm.send(None, dest=0, tag=EXIT)


### You have to specify the array size in the producer.
### This function will produce chunk and send it to the nodes.
def producer(chunk,process):
    ### Make a list of numbers and divide it into chunks.
    arraySize = 100000
    data=np.arange(1,arraySize)
    random.shuffle(data)
    data = list(data)
    smalldata = chunkIt(data, chunk)
    finallist = []
    start = 0
    end = chunk
    for i in range(1, process):
        comm.send(smalldata[i-1], dest=i, tag=START)
        #comm.send(1, dest=i, tag=START)
        
    finish = process-1
    while len(finallist)<len(data):
        data2 = comm.recv(source=MPI.ANY_SOURCE, tag=MPI.ANY_TAG, status=status)
        tag = status.Get_tag()
    
        if tag == DONE:
            finallist = customMerge(data2,finallist)
            if finish+1 <=chunk:
                comm.send(list(smalldata[finish]), dest=status.Get_source(), tag=START)
                finish=finish+1
                
            #comm.send(data[start+(i-1)*chunk:end+(i-1)*chunk], dest=i, tag=START)
    print(finallist)
    



if __name__=="__main__":
    import timeit
    start = timeit.default_timer()
    
    if rank == 0:
        ### Process with rank 0 is the processor. Specify the chunk and the number of processors.
        chunk = 32
        process = 4 
        producer(chunk,process)
        for loop in range(1,process):
            comm.send(None, dest=loop, tag=EXIT)
        stop = timeit.default_timer()
        print('Time: ', stop - start)        
    else:
        consumer_daemon()

  
