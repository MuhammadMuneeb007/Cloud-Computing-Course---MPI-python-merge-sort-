#BSUB -n 8
#BSUB -R span[ptile=4]
#BSUB -q training
#BSUB -J Hello[1-10]
#BSUB -o Hello.%J.%I.out
#BSUB -e Hello.%J.%I.err

module load anaconda/3
source /apps/anaconda/anaconda3/etc/profile.d/conda.sh
conda deactivate
conda activate ../env

radius=`head -n$LSB_JOBINDEX input.txt | tail -n1`

python hello.py $radius
