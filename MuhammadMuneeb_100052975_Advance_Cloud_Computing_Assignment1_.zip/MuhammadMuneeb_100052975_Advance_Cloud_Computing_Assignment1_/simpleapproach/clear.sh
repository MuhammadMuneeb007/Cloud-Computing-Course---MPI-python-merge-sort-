rm *.ob
rm *.out
rm *.err
