from mpi4py import MPI
from random import seed
from random import randint
from random import randrange
import random
import numpy as np
import math
import timeit
import time
import sys, getopt
def merge_sort(array, left_index, right_index):
    if left_index >= right_index:
        return

    middle = (left_index + right_index)//2
    merge_sort(array, left_index, middle)
    merge_sort(array, middle + 1, right_index)
    merge(array, left_index, right_index, middle)
def merge(array, left_index, right_index, middle):
    # Make copies of both arrays we're trying to merge

    # The second parameter is non-inclusive, so we have to increase by 1
    left_copy = array[left_index:middle + 1]
    right_copy = array[middle+1:right_index+1]

    # Initial values for variables that we use to keep
    # track of where we are in each array
    left_copy_index = 0
    right_copy_index = 0
    sorted_index = left_index

    # Go through both copies until we run out of elements in one
    while left_copy_index < len(left_copy) and right_copy_index < len(right_copy):

        # If our left_copy has the smaller element, put it in the sorted
        # part and then move forward in left_copy (by increasing the pointer)
        if left_copy[left_copy_index] <= right_copy[right_copy_index]:
            array[sorted_index] = left_copy[left_copy_index]
            left_copy_index = left_copy_index + 1
        # Opposite from above
        else:
            array[sorted_index] = right_copy[right_copy_index]
            right_copy_index = right_copy_index + 1

        # Regardless of where we got our element from
        # move forward in the sorted part
        sorted_index = sorted_index + 1

    # We ran out of elements either in left_copy or right_copy
    # so we will go through the remaining elements and add them
    while left_copy_index < len(left_copy):
        array[sorted_index] = left_copy[left_copy_index]
        left_copy_index = left_copy_index + 1
        sorted_index = sorted_index + 1

    while right_copy_index < len(right_copy):
        array[sorted_index] = right_copy[right_copy_index]
        right_copy_index = right_copy_index + 1
        sorted_index = sorted_index + 1    
def mergeSort(arr):
    if len(arr) > 1:
 
         # Finding the mid of the array
        mid = len(arr)//2
 
        # Dividing the array elements
        L = arr[:mid]
 
        # into 2 halves
        R = arr[mid:]
 
        # Sorting the first half
        mergeSort(L)
 
        # Sorting the second half
        mergeSort(R)
 
        i = j = k = 0
 
        # Copy data to temp arrays L[] and R[]
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1
 
        # Checking if any element was left
        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1
 
        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1 
def printList(arr):
    for i in range(len(arr)):
        print(arr[i], end=" ")
    print()
def customMerge(test_list1,test_list2):
    size_1 = len(test_list1) 
    size_2 = len(test_list2) 
  
    res = [] 
    i, j = 0, 0
  
    while i < size_1 and j < size_2: 
        if test_list1[i] < test_list2[j]:   
          res.append(test_list1[i]) 
          i += 1
  
        else: 
          res.append(test_list2[j]) 
          j += 1
  
    res = res + test_list1[i:] + test_list2[j:]
    return res 
 
seed(1)


#This function will divide the array (seq) into chunks (num)
def chunkIt(seq, num):
    avg = len(seq) / float(num)
    out = []
    last = 0.0

    while last < len(seq):
        out.append(seq[int(last):int(last + avg)])
        last += avg

    return out
 
import glob, os
 

import timeit
start = timeit.default_timer()
import pickle
###This function will be used by first job to generate the data.
def generate():
    arraySize = int(sys.argv[1])
    chunk  = int(sys.argv[2])
    data=np.arange(1,arraySize)
    random.shuffle(data)
    data = list(data)
    smalldata = chunkIt(data, chunk)
    for loop in range(0,len(smalldata)):
        with open(str(loop)+".ob", 'wb') as f:
            pickle.dump(smalldata[loop], f)

###This is the helper fuction to save the data
def save(data,loop):
    with open(str(loop)+"sorted"+".ob", 'wb') as f:
        pickle.dump(data, f)


###This is a helper function to show the array stored in format pickle
def show():
    for file in glob.glob("*_sorted.ob"):
        with open (file, 'rb') as fp:
            data2 = pickle.load(fp)
        print(data2)


###This function will be called by every processing node. This function will 
### wait until specific file which it has to process is generated. and after sorting
### this function will save it on the disk
def load_sort_save(file):
    while not os.path.exists(file):
        time.sleep(1)
    with open (file, 'rb') as fp:
        temp = pickle.load(fp)
        mergeSort(temp)
        save(temp,os.path.splitext(file)[0])
        
### This function will wait for all files to be present and then merge them.
def merge_save(names):
    finaldata = []
    filelist = []
    for loop in range(0,int(names)):
        filelist.append(str(loop)+"sorted.ob")
    
    while True:
        if all([os.path.isfile(f) for f in filelist]):
            break
        else:
            time.sleep(1)
        
    for file in glob.glob("*sorted.ob"):
        with open (file, 'rb') as fp:
            data2 = pickle.load(fp)
            finaldata = customMerge(data2,finaldata)
    return finaldata

import timeit
start = timeit.default_timer()
###This condition is for the generate job
if len(sys.argv)>2 and sys.argv[1]!="merge":
    generate()
elif sys.argv[1]=="merge":  ###This condition is for the merge job.
    data = merge_save(sys.argv[2])
    print(data)
    stop = timeit.default_timer()
    print('Time: ', stop - start)   
else:
    load_sort_save(sys.argv[1])### This is for the processing job.
 